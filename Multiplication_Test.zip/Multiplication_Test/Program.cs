﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiplication_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Please enter two positive integer number for processing ");
                Console.WriteLine("Start number : ");
                var sNumber = Console.ReadLine();
                int iStart = Validation_number(sNumber);
                Console.WriteLine("End number : ");
                var eNumber = Console.ReadLine();
                int iEnd = Validation_number(eNumber);
                Process_Data(iStart, iEnd);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error  : " + ex.Message);
                Console.ReadKey();
            }
        }
        /// <summary>
        /// This is the fuction for processing result
        /// </summary>
        /// <param name="iStart"></param>
        /// <param name="iEnd"></param>
        private static void Process_Data(int iStart, int iEnd)
        {
            try
            {
                int stepby = 1;
                if (iStart > iEnd) { stepby = -1; iEnd--; }
                else iEnd++;
                Console.WriteLine("Please see the below results ");
                StringBuilder strResult = new StringBuilder();
                while (iStart != iEnd)
                {
                    strResult.Clear();
                    Check_multiple(iStart, strResult);
                    Check_lastNumber(iStart, strResult);
                    Console.WriteLine(iStart + strResult.ToString());
                    iStart += stepby;
                }

                Console.ReadKey();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        /// <summary>
        /// This function is to check the division configured in app config
        /// </summary>
        /// <param name="intNumber"></param>
        /// <param name="strResult"></param>
        private static void Check_multiple(int intNumber, StringBuilder strResult)
        {
            string StrMultiple = ConfigurationManager.AppSettings.Get("Multiple_Check");
            string[] MultipleList = StrMultiple.Split(",".ToCharArray());
            foreach (string mValue in MultipleList)
            {
                int iDiv = Convert.ToInt32(mValue);
                if (intNumber % iDiv == 0)
                {
                    if (strResult.Length == 0)
                        strResult.Append(" multiple of " + iDiv.ToString());
                    else
                        strResult.Append("," + iDiv.ToString());
                }
            }
        }
        /// <summary>
        /// This function is to check the last digit configured in app config
        /// </summary>
        /// <param name="intNumber"></param>
        /// <param name="strResult"></param>
        private static void Check_lastNumber(int intNumber, StringBuilder strResult)
        {
            try
            {
                string StrMultiple = ConfigurationManager.AppSettings.Get("LastNumber_Check");
                string[] MultipleList = StrMultiple.Split(",".ToCharArray());
                foreach (string mValue in MultipleList)
                {
                    int iDiv = Convert.ToInt32(mValue);
                    if (intNumber % 10 == iDiv)
                        strResult.Append(" ends in " + iDiv.ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// This function is to validate the input numbers  
        /// </summary>
        /// <param name="sNumber"></param>
        /// <returns></returns>
        private static int Validation_number(string sNumber)
        {
            int iNumber = 0;
            bool valid = true;
            try
            {
                if (int.TryParse(sNumber, out iNumber))
                {
                    iNumber = Convert.ToInt32(sNumber);
                    if (iNumber <= 0)
                        valid = false;
                }
                else
                    valid = false;
                if (!valid)
                {
                    Console.WriteLine("The input is invalid. Please re-run the application !");
                    Console.ReadKey();
                    Environment.Exit(0);
                }
                return iNumber;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
